import React, { useState, useEffect } from "react";
import "./Page1.css";
import Navbar from "./Navbar";
import Contact from "./Contact";
import Header from "./Header";
import Resume from "./Resume";
import Portfolio from "./Portfolio";
import About from "./About";


const Page1 = () => {
  const [scroll, setScroll] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScroll(window.scrollY > 0);
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <div>
      <div className="div0">
        <Navbar />
        <section id="home">
          <Header />
        </section>
      </div>

      <section id="about">
        <About />
      </section>


      <section id="portfolio">
        <Portfolio />
      </section>

      <section id="resume">
        <Resume />
      </section>

      
      <section id="contact">
        <Contact />
      </section>

    </div>
  );
};

export default Page1;
