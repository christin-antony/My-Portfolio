import React, { useEffect, useRef } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";
import ima1 from "./image/a.png";
import ima2 from "./image/b.png";
import ima3 from "./image/c.png";
import ima4 from "./image/d.png";
import ima5 from "./image/e.png";
import "swiper/css";
import "swiper/css/effect-coverflow";
import "swiper/css/pagination";
import "./Page1";
import { EffectCoverflow, Pagination } from "swiper/modules";
import { gsap } from "gsap";

const Portfolio = () => {
  const divportRef = useRef(null);

  useEffect(() => {
    const tl = gsap.timeline({ repeat: -1, repeatDelay: 10 });
    tl.fromTo(
      divportRef.current,
      { rotationX: -180 },
      { rotationX: 0, duration: 1, ease: "power2.out" }
    );
  }, []);
  return (
    <div
      style={{
        backgroundColor: "black",
      }}
    >
      <h1 className="ph">my portfolio </h1>

      <div className="divport" ref={divportRef}>
        <Swiper
          effect={"coverflow"}
          grabCursor={true}
          centeredSlides={true}
          slidesPerView={"auto"}
          coverflowEffect={{
            rotate: 50,
            stretch: 0,
            depth: 100,
            modifier: 1,
            slideShadows: true,
          }}
          pagination={true}
          modules={[EffectCoverflow, Pagination]}
          className="mySwiper"
        >
          <SwiperSlide>
            <Card style={{ width: "1000px", backgroundColor: "rgb(25, 5, 44)" }}>
              <Card.Img variant="top" src={ima2} className="img-card" />
              <Card.Body className="card-body">
                <Card.Title className="card-text">
                  KidKinder web Application
                </Card.Title>
                <Card.Text className="card-p">
                  My KidKinder app is a full-stack web application built using
                  the MERN stack (MongoDB, Express.js, React, and Node.js).It
                  provides a platform for parents to book classes and educators
                  to access educational resources.
                </Card.Text>
                <button className="btn btn__primary" style={{marginTop:"70px"}}>Open</button>
              </Card.Body>
            </Card>
          </SwiperSlide>
          <SwiperSlide>
            <Card style={{ width: "1000px", backgroundColor: "rgb(25, 5, 44)" }}>
              <Card.Img variant="top" src={ima1} className="img-card" />
              <Card.Body className="card-body">
                <Card.Title className="card-text">Netflix clone</Card.Title>
                <Card.Text className="card-p">
                  My MERN stack Netflix clone is a full-stack web application
                  developed with MongoDB, Express.js, React, and Node.js. It
                  mimicking the essential functionalities of Netflix.
                </Card.Text>
                <button className="btn btn__primary">Open</button>
              </Card.Body>
            </Card>
          </SwiperSlide>
          <SwiperSlide>
            <Card style={{ width: "1000px", backgroundColor: "rgb(25, 5, 44)" }}>
              <Card.Img variant="top" src={ima3} className="img-card" />
              <Card.Body className="card-body">
                <Card.Title className="card-text">
                  Blog Management web Application
                </Card.Title>
                <Card.Text className="card-p">
                  My blog management system is a full-stack web application
                  created using the MERN stack (MongoDB, Express.js, React, and
                  Node.js). It allows admin to create, edit, and delete blog
                  posts.
                </Card.Text>
                <button className="btn btn__primary">Open</button>
              </Card.Body>
            </Card>
          </SwiperSlide>
          <SwiperSlide>
            <Card style={{ width: "1000px", backgroundColor: "rgb(25, 5, 44)" }}>
              <Card.Img variant="top" src={ima4} className="img-card" />
              <Card.Body className="card-body">
                <Card.Title className="card-text">Card Title</Card.Title>
                <Card.Text className="card-p">
                  Some quick example text to build on the card title and make up
                  the bulk of the card's content.
                </Card.Text>
                <button className="btn btn__primary">Open</button>
              </Card.Body>
            </Card>
          </SwiperSlide>
          <SwiperSlide>
            <Card style={{ width: "1000px", backgroundColor: "rgb(25, 5, 44)" }}>
              <Card.Img variant="top" src={ima5} className="img-card" />
              <Card.Body className="card-body">
                <Card.Title className="card-text">YouTube clone</Card.Title>
                <Card.Text className="card-p">
                  My MERN stack YouTube clone is a full-stack web application
                  built using MongoDB, Express.js, React, and Node.js. It allows
                  users to upload and view on videos, replicating core features
                  of YouTube
                </Card.Text>
                <button className="btn btn__primary">Open</button>
              </Card.Body>
            </Card>
          </SwiperSlide>
        </Swiper>
      </div>
    </div>
  );
};

export default Portfolio;
