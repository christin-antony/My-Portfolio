import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';
import './Page1.css';

const Header = () => {
  const p2Ref = useRef(null);

  useEffect(() => {
    const letters = p2Ref.current.querySelectorAll('span');
    gsap.fromTo(letters, 
      { opacity: 0, rotationX: -90 }, 
      { opacity: 1, rotationX: 0, duration: 1.5, ease: 'back.out',repeat:-1, stagger: 0.1 }
    );
  }, []);

  return (
    <div>
      <div className="div2">
        <p className="p1">Hello, I'm</p>
        <p className="p2" ref={p2Ref}>
          {Array.from("CHRISTIN").map((letter, index) => (
            <span key={index}>{letter}</span>
          ))}
          <span className="space">&nbsp;</span>
          {Array.from("ANTONY").map((letter, index) => (
            <span key={index + 8}>{letter}</span> // Key offset to avoid duplicate keys
          ))}
        </p>
        <marquee behavior="" direction="left" className="p3">MERN Stack Developer</marquee>
      </div>
    </div>
  );
};

export default Header;
