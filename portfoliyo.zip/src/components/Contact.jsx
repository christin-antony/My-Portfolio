import React from 'react'
import './Page1.css'

const Contact = () => {
  return (
    <div>
        <div className="div8">
        <p className="p8">Get In Touch</p>
        <div className="div88">
          <div className="div9">
            <p className="p9">Get In Touch</p>
            <input type="text" placeholder="Your Name" className="in1" />
            <input type="text" placeholder="Your Email" className="in1" />
            <input type="text" placeholder="Your Phone" className="in1" />
            <textarea className="in2" placeholder="Write a Message"></textarea>
            <button className="btn1">Send</button>
          </div>
          <div>
            <p className="p99">My Contact Details</p>

            <div className='Co-div'>
            <p className="p12">EMAIL</p>

            <p className="p11">christinantony057@gmail.com</p>
            </div>
            <div className='Co-div'>
            <p className="p12">PHONE</p>
            

            <p className="p11">8593899533</p>
            </div>
            <div className='Co-div'>
            <p className="p12">Linkedin</p>

            <p className="p11">www.linkedin.com/in/christin-antony
</p>
            </div>
            <div className='Co-div'>
            <p className="p12">GitHub</p>
          
            
            <p className="p11">
            www.github.com/christin-antony
             
            </p>
            </div>
          </div>
        </div>
      </div>

    </div>
  )
}

export default Contact