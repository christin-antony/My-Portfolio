import React, { useEffect } from "react";
import "./Page1.css";
import { gsap } from "gsap";
import { TextPlugin } from "gsap/TextPlugin";
gsap.registerPlugin(TextPlugin);


const Resume = () => {
  useEffect(() => {
    gsap.fromTo(
      ".div5",
      { opacity: 0, y: 50, rotationY: 90 },
      {
        opacity: 1,
        y: 0,
        rotationY: 0,
        duration: 1,
        ease: "power4.out",
        stagger: 1,
        repeat: -1, // repeat indefinitely
        yoyo: true, // reverse the animation on each repeat
      }
    );
    gsap.fromTo(
      ".div55",
      { opacity: 0, y: 50, rotationY: 90 },
      {
        opacity: 1,
        y: 0,
        rotationY: 0,
        duration: 1,
        ease: "power4.out",
        stagger: 1,
        repeat: -1, // repeat indefinitely
        yoyo: true, // reverse the animation on each repeat
      }
    );
    gsap.fromTo(
      ".card-s",
      { opacity: 0, x: 50, rotationx: 90 },
      {
        opacity: 1,
        y: 0,
        rotationx: 360,
        duration: 1,
        ease: "power4.out",
        repeat: -1,
        stagger: 0.1,

        yoyo: true, // reverse the animation on each repeat
      }
    );
  }, []);

  return (
    <div>
      <div className="div3">
        <h1 className="p4">My Resume</h1>
        
          <h1 className="t_h">Technical Skill</h1>
          <div className="T_C">
            <div className="card-s">HTML</div>
            <div className="card-s">CSS</div>
            <div className="card-s">Bootstrap</div>
            <div className="card-s">Gsap</div>
            <div className="card-s">JavaScript</div>
            <div className="card-s">MongoDB</div>
            <div className="card-s">ExpressJs</div>
            <div className="card-s">ReactJs</div>
            <div className="card-s">NodeJs</div>
            <div className="card-s">JWT</div>
            <div className="card-s">JSX</div>
            <div className="card-s">EJS</div>
            <div className="card-s">Git and GitHub</div>
            <div className="card-s">VCS</div>
            <div className="card-s">Web design</div>
            <div className="card-s">API Integration</div>
            <div className="card-s">
              Frontend <br /> development
            </div>
            <div className="card-s">
              Backend <br /> development
            </div>
            <div className="card-s">
              Deployment <br /> and Hosting
            </div>
            <div className="card-s">CRUD</div>
          </div>
        
        <div className="div4">
          <div>
            <h1 className="p5">Education</h1>
            <div className="div5">
              Jai Bharath College of Management and Engineering Technology
              (affiliated to ktu University) <br /> B. TECH COMPUTER SCIENCE
              ENGINEERING <br /> Completed in 2022
            </div>
            <div className="div5">
              L. B. S. M. H. S. S AVITTATHUR <br />
              12th <br /> Completed in 2017
            </div>
            <div className="div5">
              ST MARY'S H. S. S, IRINJALAKUDA <br />
              10th <br /> Completed in 2015
            </div>
          </div>
          <div>
            <h1 className="p5">Experience</h1>
            <div className="div55">
              MERN stack developer internship trainee <br />
              GALTech Technologies Pvt. Ltd. <br />
              2024 – Present
            </div>
            <div className="div55">
              Through this intensive program, I have gained indepth knowledge
              and hands-on experience with MongoDB, Express.js, React, and
              Node.js.
            </div>
            <div className="div55">
              The training has also enhanced my problemsolving skills and my
              ability to work effectively in a team.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Resume;
